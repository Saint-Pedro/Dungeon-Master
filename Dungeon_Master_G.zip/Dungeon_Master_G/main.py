import pygame
import os
import sys
import random
from typing import List
from data import (
    WINDOW_WIDTH, WINDOW_HEIGHT, HERO_SIZE, ENEMY_SIZE, 
    DICE_SIZE, SPRITE_SIZE, ROOM_WIDTH, ROOM_HEIGHT,
    WHITE, BLACK, GRAY,
    ENNEMIS, MESSAGES_SURVIE, DESCRIPTIONS_SALLES_VIDES,
    GameState
)

pygame.init()
screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Dungeon Master")
clock = pygame.time.Clock()

def transition_salle(screen):
    """Effet de transition entre les salles"""
    fade_surface = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
    fade_surface.fill(BLACK)
    for alpha in range(0, 255, 5):
        fade_surface.set_alpha(alpha)
        screen.blit(fade_surface, (0,0))
        pygame.display.flip()
        pygame.time.delay(5)
    for alpha in range(255, 0, -5):
        fade_surface.set_alpha(alpha)
        screen.blit(fade_surface, (0,0))
        pygame.time.delay(5)

def load_image(name: str) -> pygame.Surface:
    try:
        image = pygame.image.load(os.path.join('assets', 'images', name))
        return image.convert_alpha()
    except pygame.error as e:
        print(f"Impossible de charger l'image {name}: {e}")
        sys.exit(1)

hero_img = load_image('hero.png')
enemy_img = load_image('enemy.png')
room_img = load_image('room.png')
heart_img = load_image('heart.png')
dice_img = load_image('dice.png')
gameover_img = load_image('gameover.png')

hero_img = pygame.transform.scale(hero_img, (HERO_SIZE, HERO_SIZE))
enemy_img = pygame.transform.scale(enemy_img, (ENEMY_SIZE, ENEMY_SIZE))
heart_img = pygame.transform.scale(heart_img, (32, 32))
dice_img = pygame.transform.scale(dice_img, (96, 64))
room_img = pygame.transform.scale(room_img, (ROOM_WIDTH, ROOM_HEIGHT))
gameover_img = pygame.transform.scale(gameover_img, (ROOM_WIDTH, ROOM_HEIGHT))

class GameState:
    def __init__(self):
        self.vie = 1
        self.salle_actuelle = 0
        self.niveau = self.generer_niveau()
        self.en_combat = False
        self.resultat_de = None
        self.message = "Appuyez sur ESPACE pour commencer"
        self.message_secondaire = ""
        self.message_pv = ""
        self.game_over = False
        self.victoire = False
        self.tentatives = 1
        self.ennemi_actuel = None
        self.phase_combat = 0

    def generer_niveau(self) -> List[int]:
        return [random.randint(0, 1) for _ in range(20)]

    def lancer_de(self) -> int:
        return random.randint(1, 6)

    def nouvelle_partie(self):
        self.vie = 1
        self.salle_actuelle = 0
        self.niveau = self.generer_niveau()
        self.en_combat = False
        self.resultat_de = None
        self.message = "Appuyez sur ESPACE pour avancer"
        self.message_secondaire = ""
        self.message_pv = ""
        self.game_over = False
        self.tentatives += 1
        self.ennemi_actuel = None
        self.phase_combat = 0

def dessiner_interface(screen: pygame.Surface, state: GameState):
    screen.fill(BLACK)
    
    room_x = (WINDOW_WIDTH - ROOM_WIDTH) // 2
    room_y = (WINDOW_HEIGHT - ROOM_HEIGHT) // 2

    if state.game_over and not state.victoire:
        screen.blit(gameover_img, (room_x, room_y))
        
        font = pygame.font.Font(None, 36)
        text = font.render("Appuyez sur R pour recommencer", True, WHITE)
        text_rect = text.get_rect(center=(WINDOW_WIDTH/2, WINDOW_HEIGHT - 50))
        screen.blit(text, text_rect)
        return

    screen.blit(room_img, (room_x, room_y))

    hero_x = room_x + ROOM_WIDTH//4 - HERO_SIZE//2
    hero_y = room_y + ROOM_HEIGHT - HERO_SIZE - 20
    screen.blit(hero_img, (hero_x, hero_y))

    if state.en_combat:
        enemy_x = room_x + (ROOM_WIDTH * 3)//4 - ENEMY_SIZE//2
        enemy_y = room_y + ROOM_HEIGHT - ENEMY_SIZE - 60
        screen.blit(enemy_img, (enemy_x, enemy_y))


    for i in range(state.vie):
        screen.blit(heart_img, (10 + i * 40, 10))
    
    if state.message_pv:
        message_font = pygame.font.Font(None, 24)
        text = message_font.render(state.message_pv, True, WHITE)
        text_rect = text.get_rect(midleft=(10 + (state.vie * 40) + 10, 25))
        screen.blit(text, text_rect)

    if state.phase_combat >= 2 and state.resultat_de is not None:
        dice_x = WINDOW_WIDTH - 120
        dice_y = 10
        screen.blit(dice_img, (dice_x, dice_y))
        font = pygame.font.Font(None, 48)
        text = font.render(str(state.resultat_de), True, WHITE)
        text_rect = text.get_rect(center=(dice_x + DICE_SIZE//2, dice_y + DICE_SIZE + 10))
        screen.blit(text, text_rect)

    font = pygame.font.Font(None, 36)
    text = font.render(state.message, True, WHITE)
    text_rect = text.get_rect(center=(WINDOW_WIDTH/2, WINDOW_HEIGHT - 30))
    screen.blit(text, text_rect)

    if state.message_secondaire:
        message_font = pygame.font.Font(None, 24)
        words = state.message_secondaire.split()
        lines = []
        current_line = words[0]
        for word in words[1:]:
            if len(current_line) + len(word) + 1 <= 60:
                current_line += " " + word
            else:
                lines.append(current_line)
                current_line = word
        lines.append(current_line)
        
        for i, line in enumerate(lines):
            text = message_font.render(line, True, WHITE)
            text_rect = text.get_rect(center=(WINDOW_WIDTH/2, WINDOW_HEIGHT - 120 + i * 20))
            screen.blit(text, text_rect)

    progress = font.render(f"Salle {state.salle_actuelle + 1}/20", True, WHITE)
    screen.blit(progress, (10, WINDOW_HEIGHT - 40))

def main():
    state = GameState()
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and not state.game_over:
                    if state.salle_actuelle < 20:
                        if not state.en_combat and state.phase_combat == 0:
                            state.en_combat = state.niveau[state.salle_actuelle] == 1
                            state.message_pv = ""
                            transition_salle(screen)

                            if state.en_combat:
                                state.ennemi_actuel = random.choice(ENNEMIS)
                                state.message = "Combat !"
                                state.message_secondaire = state.ennemi_actuel.description
                                state.phase_combat = 1
                            else:
                                state.message = "Salle vide"
                                state.message_secondaire = random.choice(DESCRIPTIONS_SALLES_VIDES)
                                state.salle_actuelle += 1
                                state.resultat_de = None

                        elif state.en_combat and state.phase_combat == 1:
                            state.resultat_de = state.lancer_de()
                            state.phase_combat = 2
                            if state.resultat_de == 1:
                                state.message = "Échec critique"
                                state.message_secondaire = state.ennemi_actuel.defaite
                                state.phase_combat = 3  
                            elif state.resultat_de == 6:
                                state.message = "Succès critique"
                                state.message_secondaire = state.ennemi_actuel.victoire
                                state.message_pv = "Vous gagnez un point de vie !"
                            elif state.resultat_de <= 3:
                                state.message = "Combat perdu"
                                if state.vie > 1:
                                    state.message_secondaire = random.choice(MESSAGES_SURVIE)
                                    state.message_pv = "Vous perdez un point de vie !"
                                else:
                                    state.message_secondaire = state.ennemi_actuel.defaite
                                    state.phase_combat = 3  
                            else:
                                state.message = "Combat gagné"
                                state.message_secondaire = state.ennemi_actuel.victoire

                        elif state.en_combat and state.phase_combat == 2:
                            if state.resultat_de == 6:
                                state.vie += 1
                                state.salle_actuelle += 1
                                state.en_combat = False
                                state.phase_combat = 0
                            elif state.resultat_de <= 3:
                                state.vie -= 1
                                if state.vie <= 0:
                                    state.phase_combat = 3
                                else:
                                    state.salle_actuelle += 1
                                    state.en_combat = False
                                    state.phase_combat = 0
                            else:
                                state.salle_actuelle += 1
                                state.en_combat = False
                                state.phase_combat = 0

                            if state.salle_actuelle >= 20:
                                state.message = "Victoire ! Appuyez sur R pour recommencer"
                                state.message_secondaire = "Vous avez survécu aux dangers du donjon !"
                                state.victoire = True
                                state.game_over = True

                        elif state.en_combat and state.phase_combat == 3:
                            state.game_over = True

                elif event.key == pygame.K_r and state.game_over:
                    state.nouvelle_partie()

        dessiner_interface(screen, state)
        pygame.display.flip()
        clock.tick(60)

    pygame.quit()

if __name__ == "__main__":
    main()