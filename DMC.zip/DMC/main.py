import time
import random
from data import *

def traverse_niveau(niveau):
    vie = 1
    for i, salle in enumerate(niveau):
        print(f"\n{'-'*50}")
        print(f"Salle {i+1}/20:")
        print(f"Points de vie actuels : {'❤️ ' * vie}")
        time.sleep(1)
        
        if salle == 1:  # ennemi
            ennemi = get_combat_description()
            print(f"\n⚔️  {ennemi.description}. Préparez-vous au combat!")
            time.sleep(2)
            
            resultat_de = random.randint(1, 6)
            print(f"\nLancer de dé : {resultat_de}")
            time.sleep(1)
            
            if resultat_de == 1:  
                print("\n💀 ÉCHEC CRITIQUE ! 💀")
                print(f"\n{ennemi.defaite}")
                return False
            elif resultat_de == 6:  
                print("\n✨ SUCCÈS CRITIQUE ! ✨")
                print(f"\n{ennemi.victoire}")
                vie += 1
                print(f"Vous gagnez un point de vie ! (Total: {vie})")
            elif resultat_de <= 3:
                print("\n❌ Le combat tourne mal !")
                print(f"\n{ennemi.defaite}")
                vie -= 1
                if vie <= 0:
                    return False
                else:
                    print(f"\n{random.choice(MESSAGES_SURVIE)}")
                    print(f"Vous perdez 1 point de vie. Points de vie restants: {vie}")
            else:
                print("\n✅ Vous triomphez !")
                print(f"\n{ennemi.victoire}")
        else:
            print(f"\n🏃 {get_empty_room_description()}")
        
        input("\nAppuyez sur Entrée pour continuer...")
        
    return True

def main():
    tentatives = 0
    victoire = False
    
    print("\n=== DUNGEON MASTER ===\n")
    print("Règles:")
    print("- Vous commencez avec 1 point de vie")
    print("- □ = salle vide (sûre)")
    print("- ■ = salle avec ennemi (combat)")
    print("\nSystème de combat:")
    print("Lancer de dé (1-6):")
    print("  * 1: ÉCHEC CRITIQUE - Mort instantanée")
    print("  * 2-3: Vous perdez 1 point de vie (si vous en avez encore, vous parvenez à fuir)")
    print("  * 4-5: Vous survivez au combat")
    print("  * 6: SUCCÈS CRITIQUE - Vous gagnez 1 point de vie")
    print("\nObjectif: traverser un niveau complet sans mourir\n")
    
    input("Appuyez sur Entrée pour commencer l'aventure...")
    
    while not victoire:
        tentatives += 1
        niveau = generer_niveau()
        print(f"\n{'='*50}")
        print(f"=== Niveau {tentatives} ===")
        print(f"{'='*50}")
        print("\nPlan du niveau:")
        print(afficher_niveau(niveau))
        print("\nDébut de l'exploration...")
        input("Appuyez sur Entrée pour commencer ce niveau...")
        
        victoire = traverse_niveau(niveau)
        if not victoire:
            print("\n💀 Votre aventure s'achève ici...")
            while True:
                reponse = input("\nAppuyez sur 'R' pour tenter une nouvelle aventure : ").upper()
                if reponse == 'R':
                    break
        else:
            print("\n🏆 Victoire! Vous avez survécu aux dangers du donjon!")
    
    print(f"\nVotre légende s'achève ici ! {tentatives} tentatives auront été nécessaires pour triompher!")
    input("\nAppuyez sur Entrée pour quitter...")

if __name__ == "__main__":
    main()